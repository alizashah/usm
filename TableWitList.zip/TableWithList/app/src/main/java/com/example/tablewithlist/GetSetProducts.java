package com.example.tablewithlist;

public class GetSetProducts {

    public String SALECODE;
    public String MCODE;
    public String FNAME;
    public String LNAME;
    public String URDUNAME;
    public String ADDRESS;
    public String CONTACT;
    public String CNIC;
    public String SALETYPE;
    public String ROUTE;
    public String AREA;
    public String ZONE;
    public String BALANCE;
    public String CREDITLIMIT;
    public String SPL;
    public String SALETAX;

    public String getSALECODE() {
        return SALECODE;
    }

    public void setSALECODE(String SALECODE) {
        this.SALECODE = SALECODE;
    }

    public String getMCODE() {
        return MCODE;
    }

    public void setMCODE(String MCODE) {
        this.MCODE = MCODE;
    }

    public String getFNAME() {
        return FNAME;
    }

    public void setFNAME(String FNAME) {
        this.FNAME = FNAME;
    }

    public String getLNAME() {
        return LNAME;
    }

    public void setLNAME(String LNAME) {
        this.LNAME = LNAME;
    }

    public String getURDUNAME() {
        return URDUNAME;
    }

    public void setURDUNAME(String URDUNAME) {
        this.URDUNAME = URDUNAME;
    }

    public String getADDRESS() {
        return ADDRESS;
    }

    public void setADDRESS(String ADDRESS) {
        this.ADDRESS = ADDRESS;
    }

    public String getCONTACT() {
        return CONTACT;
    }

    public void setCONTACT(String CONTACT) {
        this.CONTACT = CONTACT;
    }

    public String getCNIC() {
        return CNIC;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }

    public String getSALETYPE() {
        return SALETYPE;
    }

    public void setSALETYPE(String SALETYPE) {
        this.SALETYPE = SALETYPE;
    }

    public String getROUTE() {
        return ROUTE;
    }

    public void setROUTE(String ROUTE) {
        this.ROUTE = ROUTE;
    }

    public String getAREA() {
        return AREA;
    }

    public void setAREA(String AREA) {
        this.AREA = AREA;
    }

    public String getZONE() {
        return ZONE;
    }

    public void setZONE(String ZONE) {
        this.ZONE = ZONE;
    }

    public String getBALANCE() {
        return BALANCE;
    }

    public void setBALANCE(String BALANCE) {
        this.BALANCE = BALANCE;
    }

    public String getCREDITLIMIT() {
        return CREDITLIMIT;
    }

    public void setCREDITLIMIT(String CREDITLIMIT) {
        this.CREDITLIMIT = CREDITLIMIT;
    }

    public String getSPL() {
        return SPL;
    }

    public void setSPL(String SPL) {
        this.SPL = SPL;
    }

    public String getSALETAX() {
        return SALETAX;
    }

    public void setSALETAX(String SALETAX) {
        this.SALETAX = SALETAX;
    }
}
