package com.example.tablewithlist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.tablewithlist.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lalit on 9/12/2016.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 2;
    Context context;

    // Database Name
    private static final String DATABASE_NAME = "DynamicERP.db";

    public  static final String table_imei = "IMEITABLE";
    public  static final String table_login= "USERLOGIN";
    public  static final String table_orders = "TABLEORDERS";
    public  static final String table_poducts_records= "PRODUCTSRECORDS";
    // User Table Columns names

    public static final String imeiid = "IMEIID";
    public static final String imei = "IMEI";


    public static final String userid = "USERID";
    public static final String username = "USERNAME";
    public static final String password = "PASSWORD";
    public static final String userrole = "USERROLE";


    public static final String code = "ORDERCODE";
    public static final String barcode = "BARCODE";
    public static final String nametblp = "NAME";
    public static final String size = "SIZE";
    public static final String uname = "UNAME";
    public static final String retail = "RETAIL";
    public static final String wholesale = "WHOLESALE";
    public static final String trade = "TRADE";
    public static final String percentage = "PERCENTAGE";
    public static final String tax = "TAX";
    public static final String subcatagary = "SUBCATAGARY";
    public static final String categary = "CATEGARY";
    public static final String company = "COMPANY";
    public static final String type = "TYPE";
    public static final String packsize = "PACKSIZE";
    public static final String weight = "WEIGHT";
    public static final String weightunit = "WEIGHTUNIT";
    public static final String currentstock = "CURRENTSTOCK";



    public static final String salecode = "SALECODE";
    public static final String mcode = "MCODE";
    public static final String fname = "FIRSTNAME";
    public static final String lname = "LASTNAME";
    public static final String urduname = "URDUNAME";
    public static final String address = "ADDRESS";
    public static final String contact = "CONTACT";
    public static final String cnic = "CNIC";
    public static final String saletype = "TYPE";
    public static final String route = "ROUTE";
    public static final String area = "AREA";
    public static final String zone = "ZONE";
    public static final String balance = "BALANCE";
    public static final String creditlimit = "CREDITLIMIT";
    public static final String spl = "SPL";
    public static final String saletax = "SALETAX";


    // create table sql query
    private static final String DATABASE_CIMEI = "CREATE TABLE " + table_imei + "("
            + imeiid + " INTEGER, " + imei + " VARCHAR );" ;

    private static final String DATABASE_CUSER = "CREATE TABLE " + table_login + "("
            + userid + " INTEGER, " + username + " VARCHAR, " + password + " INTEGER, " + userrole + " VARCHAR );" ;

    private static final String DATABASE_ORDERS = "CREATE TABLE " + table_orders + "("
            + code + " INTEGER, " + barcode + " VARCHAR,"  + nametblp+" VARCHAR," + size + " VARCHAR," +uname+
            " VARCHAR,"  + retail + " VARCHAR,"  + wholesale + " VARCHAR,"  + trade + " VARCHAR,"
            + percentage + " VARCHAR,"  + tax + " VARCHAR,"  + subcatagary + " VARCHAR," + categary+ " VARCHAR," +
            company + " VARCHAR,"  + type +" VARCHAR,"  + packsize +" VARCHAR," +
            weight +" VARCHAR,"  + weightunit +" VARCHAR, " + currentstock +" VARCHAR );" ;


    private static final String DATABASE_PRODUCTS = "CREATE TABLE " + table_poducts_records + "("
            + salecode + " INTEGER, " + mcode + " VARCHAR, "  + fname +" VARCHAR, " + lname +" VARCHAR, " + urduname +
            " VARCHAR, " + address +" NVARCHAR, "  + contact +" VARCHAR,"  + cnic +" VARCHAR, "  + saletype + " VARCHAR,"
            + route + " VARCHAR, "  + area + " VARCHAR,"  + zone + " VARCHAR," +
            balance +" VARCHAR, "  + creditlimit +" VARCHAR,"  + spl +" VARCHAR, " + saletax + " VARCHAR);" ;


    // drop table sql query
    String DROP_IMEI_TABLE = "DROP TABLE IF EXISTS " + table_imei;
    private String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + table_login;
    private String DROP_ORDER_REC = "DROP TABLE IF EXISTS " + table_orders;
    private String DROP_PRODUCTS_REC = "DROP TABLE IF EXISTS " + table_poducts_records;

    /**
     * Constructor
     *
     * @param context
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DATABASE_CIMEI);
        db.execSQL(DATABASE_CUSER);
        db.execSQL(DATABASE_ORDERS);
        db.execSQL(DATABASE_PRODUCTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //Drop User Table if exist
        db.execSQL(DROP_USER_TABLE);
        db.execSQL(DROP_IMEI_TABLE);
        db.execSQL(DROP_PRODUCTS_REC);
        db.execSQL(DROP_ORDER_REC);

        // Create tables aga
        onCreate(db);

    }

    public void addProductRec() {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(salecode, "123456");
        values.put(mcode, "123654698");
        values.put(fname, "Usman");
        values.put(lname, "Ali");
        values.put(urduname, "Usman");
        values.put(contact, "021354545");
        values.put(cnic, "54548787515");
        values.put(saletype, "credit");
        values.put(route, "{Peshawer Road");
        values.put(area, "wah");
        values.put(zone, "Rawalpindi");
        values.put(balance, "1000");
        values.put(creditlimit, "10000");
        values.put(spl, "212");
        values.put(saletax, "10");
        values.put(address, "wah");
        // Inserting Row
        db.insert(table_poducts_records, null, values);
        db.close();
    }


    public void addOrders() {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(code, "098766");
        values.put(barcode, "5544444445");
        values.put(nametblp, "Usman");
        values.put(size, "12");
        values.put(uname, "Ali");
        values.put(retail, "500");
        values.put(wholesale, "whole");
        values.put(trade, "credit");
        values.put(percentage, "7");
        values.put(tax, "1000");
        values.put(subcatagary, "laptop");
        values.put(categary, "computers");
        values.put(company, "hp");
        values.put(type, "laptop");
        values.put(packsize, "12");
        values.put(weight, "5");
        values.put(weightunit, "kg");
        values.put(currentstock, "57");

        // Inserting Row
        db.insert(table_orders, null, values);
        db.close();
    }


    /**
     * This method is to create user record

     */


    public void addAdmin() {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(userid,"999");
        values.put(username, "DynamicSP Admin");
        values.put(password, "999");
        values.put(userrole, "Admin");

        // Inserting Row
        db.insert(table_login, null, values);
        db.close();
    }


    public String checkNameExist(String trim) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query= "SELECT  username FROM "+table_login+ " WHERE  userid="+ trim;

       Cursor cursor = db.rawQuery(query, null);
      String userNAme = "-1";
        if(cursor.getCount() > 0) {
            cursor.moveToFirst();
            userNAme = (cursor.getString(cursor.getColumnIndex(username)));
        }
        else {

        }
        return userNAme;
    }

    public void deletePersonRecord(String useridValue, Context mContext) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(table_login, userid + "=" + useridValue, null);
        Toast.makeText(mContext, "Deleted successfully.", Toast.LENGTH_SHORT).show();
        db.close();
    }

    public void deleteIMEIRecord(String imeiidValue, Context mContext) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(table_imei, imeiid + "=" + imeiidValue, null);
        Toast.makeText(mContext, "Deleted successfully.", Toast.LENGTH_SHORT).show();
        db.close();

    }

    public boolean checkUser(String s, String trim, String userid) {

        // array of columns to fetch
        String[] columns = {
                userid
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = userid + " = ?";

        // selection argument
        String[] selectionArgs = {userid};

        Cursor cursor = db.query(table_login, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public boolean checkAdmin(String trim, String trim1, String trim2) {

        String[] colunmn ={
                userid
        };
        SQLiteDatabase db= this.getReadableDatabase();
        String selection= userid + " = ?" + " AND " + password + " = ?" + " AND " + userrole + " = 'Admin'";
        String[] selectionArgs= {trim,trim2};
        Cursor cursor=db.query(table_login,
                colunmn,
                selection,
                selectionArgs,
                null,
                null,
                null);

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }
        return false;
    }
    public boolean checkIMEIrecordExistsforLogin(String deviceId) {

        String[] column= {imei
        };
        SQLiteDatabase db= this.getReadableDatabase();

        String selection = imei + " = ?";

        // selection argument
        String[] selectionArgs = {deviceId};

        Cursor cursor= db.query(table_imei,
                column,
                selection,
                selectionArgs,
                null,
                null,
                null);
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        if (cursorCount>0){
            return true;
        }
        return false;
    }

    public boolean checkUserIDExists(String trim) {
        String[] column= {userid
        };
        SQLiteDatabase db= this.getReadableDatabase();

        String selection = userid + " = ?";

        // selection argument
        String[] selectionArgs = {trim};
        Cursor cursor= db.query(table_login,
                column,
                selection,
                selectionArgs,
                null,
                null,
                null);
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        if (cursorCount>0){
            return true;
        }
        return false;
    }

    public boolean checkIMEIrecordExists(String trim) {
        String[] column= {imei
        };
        SQLiteDatabase db= this.getReadableDatabase();

        String selection = imei + " = ?";

        // selection argument
        String[] selectionArgs = {trim};
        Cursor cursor= db.query(table_imei,
                column,
                selection,
                selectionArgs,
                null,
                null,
                null);
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        if (cursorCount>0){
            return true;
        }
        return false;
    }

    public boolean checkUserDataExists(String trim, String trim1, String trim2) {
        String[] colunmn ={
                userid
        };
        SQLiteDatabase db= this.getReadableDatabase();
        String selection= userid + " = ?" + " AND  " + password + " = ?" ;
        String[] selectionArgs= {trim,trim2};
        Cursor cursor=db.query(table_login,
                colunmn,
                selection,
                selectionArgs,
                null,
                null,
                null);

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }
        return false;
    }

    public Object getCompleteTable() {
        String[] columns = {
                salecode,
                mcode,fname,lname,urduname,contact,cnic,saletype,route,area,zone,balance,creditlimit,spl,saletax,address
        };
        // sorting orders

        String sortOrder = table_poducts_records + " ASC";
        /*List<User> userList = new ArrayList<User>();*/

//        List<TableProductsActivity> userList= (<TableProductsActivity>) new TableProductsActivity();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(table_poducts_records, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order


        // Traversing through all rows and adding to list

/*        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                //user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(userid))));
                user.setImei(cursor.getString(cursor.getColumnIndex(imei)));
                user.setImeiid(cursor.getString(cursor.getColumnIndex(imeiid)));
                // Adding user record to list
                userList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();*/

        db.close();

        // return user list
        return db;

    }
}
