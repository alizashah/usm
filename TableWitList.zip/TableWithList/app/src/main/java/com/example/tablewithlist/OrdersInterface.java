package com.example.tablewithlist;

import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class OrdersInterface {

    SQLiteDatabase database;
    DatabaseHelper dbHelper;

    private String[] allColumns = {DatabaseHelper.code, DatabaseHelper.barcode, DatabaseHelper.nametblp, DatabaseHelper.size,
            DatabaseHelper.uname, DatabaseHelper.retail, DatabaseHelper.wholesale, DatabaseHelper.trade,
            DatabaseHelper.percentage, DatabaseHelper.tax, DatabaseHelper.subcatagary, DatabaseHelper.categary,
            DatabaseHelper.company, DatabaseHelper.type, DatabaseHelper.packsize, DatabaseHelper.weight,
            DatabaseHelper.weightunit, DatabaseHelper.currentstock
    };
    public OrdersInterface(TableOrdersActivity tableLayout) {
        dbHelper = new DatabaseHelper(tableLayout);

    }

    public String open()  {
        String x = "";
        try {
            database = dbHelper.getWritableDatabase();
            x = "1";
        }
        catch (Exception e){

            x = e.toString();
        }
        return x;
    }

    public  String openforread(){
        String x = "";
        try {
            database = dbHelper.getReadableDatabase();
            x = "1";
        }
        catch (Exception e){

            x = "0";
        }
        return x;


    }


    public void close() {
        dbHelper.close();
    }

    public boolean deleteoneclient(long c)throws Exception{


        //database.delete(ProductDatabase.table_name, ProductDatabase.product + " = " + c, null);
        return database.delete(DatabaseHelper.table_orders, DatabaseHelper.code + "=" + c ,null) > 0;

    }

    public long getrowCount() {
        try {
            String countQuery = "SELECT  * FROM " + DatabaseHelper.table_orders;

            SQLiteDatabase db = dbHelper.getReadableDatabase();
            long cnt = DatabaseUtils.queryNumEntries(db, DatabaseHelper.table_orders);
            db.close();
            return cnt;
        }
        catch (Exception e){
            return 1000;
        }

    }

    public List<GetSetOrders> getAllClients(String dec, String Rou, String Typ) throws Exception{
        List<GetSetOrders> comments = new ArrayList<>();
        Cursor cursor;
        if(dec.equals("1")){
            cursor  = database.query(DatabaseHelper.table_orders, allColumns , null, null, null, null, null);
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                GetSetOrders comment = cursorToGetSetValues(cursor);
                comments.add(comment);
                cursor.moveToNext();
            }
            // make sure to close the cursor
            this.close();
            cursor.close();
        }



        else if(dec.equals("2")){
            cursor  = database.rawQuery("SELECT  ORDERCODE , BARCODE , NAME , UNAME , RETAIL , WHOLESALE , TRADE , PERCENTAGE , TAX , PERCENTAGE , TAX , SUBCATAGARY , CATEGARY ,COMPANY , TYPE , PACKSIZE , WEIGHT , WEIGHTUNIT , CURRENTSTOCK FROM  TABLEORDERS WHERE SALETYPE ='" + Typ + "' AND ROUTE ='" + Rou +"'",null);

            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                GetSetOrders comment = cursorToGetSetValues(cursor);
                comments.add(comment);
                cursor.moveToNext();
            }
            // make sure to close the cursor
            this.close();
            cursor.close();


        }

        else if(dec.equals("3")){
            cursor  = database.rawQuery("SELECT  ORDERCODE , BARCODE , NAME , UNAME , RETAIL , WHOLESALE , TRADE , PERCENTAGE , TAX , PERCENTAGE , TAX , SUBCATAGARY , CATEGARY ,COMPANY , TYPE , PACKSIZE , WEIGHT , WEIGHTUNIT , CURRENTSTOCK FROM  TABLEORDERS WHERE SALETYPE ='" + Typ + "' AND ROUTE ='" + Rou +"'",null);

            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                GetSetOrders comment = cursorToGetSetValues(cursor);
                comments.add(comment);
                cursor.moveToNext();
            }
            // make sure to close the cursor
            this.close();
            cursor.close();


        }

        return comments;
    }

    private GetSetOrders cursorToGetSetValues(Cursor cursor) throws Exception {

        GetSetOrders comm = new GetSetOrders();

        comm.setORDERCODE(cursor.getString(0));
        comm.setBARCODE(cursor.getString(1));
        comm.setNAME(cursor.getString(2));
        comm.setSIZE(cursor.getString(3));
        comm.setUNAME(cursor.getString(4));
        comm.setRETAIL(cursor.getString(5));
        comm.setWHOLESALE(cursor.getString(6));
        comm.setTRADE(cursor.getString(7));
        comm.setPERCENTAGE(cursor.getString(8));
        comm.setTAX(cursor.getString(9));
        comm.setSUBCATAGARY(cursor.getString(10));
        comm.setCATEGARY(cursor.getString(11));
        comm.setCOMPANY(cursor.getString(12));
        comm.setTYPE(cursor.getString(13));
        comm.setPACKSIZE(cursor.getString(14));
        comm.setWEIGHT(cursor.getString(15));
        comm.setWEIGHTUNIT(cursor.getString(16));
        comm.setCURRENTSTOCK(cursor.getString(17));
        return comm;

    }


}

