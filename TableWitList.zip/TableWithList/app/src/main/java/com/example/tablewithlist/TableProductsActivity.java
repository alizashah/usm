package com.example.tablewithlist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class TableProductsActivity extends AppCompatActivity {
    public  ProductInterface datasource1;
    android.widget.TableLayout t1;
    String Rou = "";
    String Typ = "";
    String Rou1 = ""; String Typ1 = "";
    List<GetSetProducts> l1;
    @RequiresApi(api = Build.VERSION_CODES.CUPCAKE)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_layout);

        Intent ag = getIntent();
        Rou= ag.getStringExtra("Rou");
        Typ= ag.getStringExtra("Typ");
        Rou1= ag.getStringExtra("Rou1");
        Typ1= ag.getStringExtra("Typ1");
        t1= (android.widget.TableLayout) findViewById(R.id.tableproducts);
        GetAllProduct("1",Rou1,Typ1);

/*        if(Rou.equals("1")&& Typ.equals("1")) {
            GetAllProduct("2",Rou1,Typ1);
        }
        else if(Rou.equals("2")&& Typ.equals("2")){

            GetAllProduct("3",Rou1,Typ1);


        }
        else if(Rou.equals("3")&& Typ.equals("3")){

            GetAllProduct("1",Rou1,Typ1);

        }*/

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_client__data__show, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public  void clientadd(Integer o1,String o2,String o3,String o4,String o5,String o6,Float o7){

        datasource1 = new ProductInterface(this);
        String openresult=  datasource1.open();
        if(openresult.equals("1")){
            try{
/*                String abc  = datasource1.CreateClient(o1,o2,o3,o4,o5, o6, o7) ;
                if(abc.equals("-1")){
//            t11.setText("not-Inserted");
                }
                else{
                    //    t11.setText("Inserted");
                }*/
            }
            catch (Exception e ){
                // t11.setText(e.toString());
            }

        }
        else{
            // t11.setText("Database is not Open");
        }


    }

    @RequiresApi(api = Build.VERSION_CODES.CUPCAKE)
    public void GetAllProduct(String d, String Rou, String Typ){

        AlertDialog alertDialog = new AlertDialog.Builder(TableProductsActivity.this).create();
        alertDialog.setTitle("Alert");
        datasource1 = new ProductInterface(this);
        long rowcount = datasource1.getrowCount();

        if(rowcount == 0 || rowcount < 0){

            alertDialog.setMessage("No Data found go back and get from file");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            Intent a = new Intent(TableProductsActivity.this, MainActivity.class);
                            startActivity(a);
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }
        else {

            String openresult=  datasource1.openforread();
            if(openresult.equals("1")){

                try {
                    int t =0;
                    l1 = datasource1.getAllClients(d, Rou, Typ);
                    if(l1.size()==0){
                        alertDialog.setMessage("No data according to your Query Go Back..");
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent a = new Intent(TableProductsActivity.this, MainActivity.class);
                                        startActivity(a);
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();

                    }

                    for (GetSetProducts cn : l1) {

                        if(t==0){
                            TableRow row= new TableRow(this);
                            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
                            row.setLayoutParams(lp);

                            TextView tv00 = new TextView(this);
                            tv00.setText("Code");
                            tv00.setBackgroundColor(Color.parseColor("#f8f8f8"));
                            tv00.setTextColor(Color.BLACK);
                            tv00.setTextSize(13);
                            tv00.setGravity(Gravity.CENTER);
                            tv00.setPadding(10, 15, 10, 15);
                            tv00.setBackgroundResource(R.drawable.item);
                            row.addView(tv00);


                            TextView tv111 = new TextView(this);
                            tv111.setText("MCode");
                            tv111.setTextColor(Color.BLACK);
                            tv111.setGravity(Gravity.CENTER);
                            tv111.setTextSize(13);
                            tv111.setPadding(10, 15, 10, 15);
                            tv111.setBackgroundResource(R.drawable.item);
                            row.addView(tv111);

                            TextView tv22 = new TextView(this);
                            tv22.setText(" FirstName ");
                            tv22.setBackgroundColor(Color.parseColor("#f8f8f8"));
                            tv22.setTextColor(Color.BLACK);
                            tv22.setTextSize(13);
                            tv22.setGravity(Gravity.CENTER);
                            tv22.setPadding(10, 15, 10, 15);
                            tv22.setBackgroundResource(R.drawable.item);
                            row.addView(tv22);

                            TextView tv33 = new TextView(this);
                            tv33.setText("LastName ");
                            tv33.setTextColor(Color.BLACK);
                            tv33.setGravity(Gravity.CENTER);
                            tv33.setPadding(10, 15, 10, 15);
                            tv33.setBackgroundResource(R.drawable.item);
                            tv33.setTextSize(13);
                            row.addView(tv33);

                            TextView tv44 = new TextView(this);
                            tv44.setText("UrduName ");
                            tv44.setBackgroundColor(Color.parseColor("#f8f8f8"));
                            tv44.setTextColor(Color.BLACK);
                            tv44.setGravity(Gravity.CENTER);
                            tv44.setTextSize(13);
                            tv44.setPadding(10, 15, 10, 15);
                            tv44.setBackgroundResource(R.drawable.item);
                            row.addView(tv44);

                            TextView tv55 = new TextView(this);
                            tv55.setText("Contact ");
                            tv55.setTextColor(Color.BLACK);
                            tv55.setTextSize(13);
                            tv55.setGravity(Gravity.CENTER);
                            tv55.setPadding(10, 15, 10, 15);
                            tv55.setBackgroundResource(R.drawable.item);
                            row.addView(tv55);

                            TextView tv66 = new TextView(this);
                            tv66.setText("CNIC ");
                            tv66.setBackgroundColor(Color.parseColor("#f8f8f8"));
                            tv66.setTextSize(13);
                            tv66.setTextColor(Color.BLACK);
                            tv66.setGravity(Gravity.CENTER);
                            tv66.setPadding(10, 15, 10, 15);
                            tv66.setBackgroundResource(R.drawable.item);
                            row.addView(tv66);

                            TextView tv67 = new TextView(this);
                            tv67.setText("SaleType ");
                            tv67.setTextColor(Color.BLACK);
                            tv67.setTextSize(13);
                            tv67.setGravity(Gravity.CENTER);
                            tv67.setPadding(10, 15, 10, 15);
                            tv67.setBackgroundResource(R.drawable.item);
                            row.addView(tv67);

                            TextView tv68 = new TextView(this);
                            tv68.setText("Route ");
                            tv68.setTextColor(Color.BLACK);
                            tv68.setGravity(Gravity.CENTER);
                            tv68.setTextSize(13);
                            tv68.setPadding(10, 15, 10, 15);
                            tv68.setBackgroundResource(R.drawable.item);
                            row.addView(tv68);


                            TextView tv69 = new TextView(this);
                            tv69.setText("Area ");
                            tv69.setTextColor(Color.BLACK);
                            tv69.setTextSize(13);
                            tv69.setGravity(Gravity.CENTER);
                            tv69.setPadding(10, 15, 10, 15);
                            tv69.setBackgroundResource(R.drawable.item);
                            row.addView(tv69);


                            TextView tv70 = new TextView(this);
                            tv70.setText("Zone ");
                            tv70.setTextColor(Color.BLACK);
                            tv70.setTextSize(13);
                            tv70.setGravity(Gravity.CENTER);
                            tv70.setPadding(10, 15, 10, 15);
                            tv70.setBackgroundResource(R.drawable.item);
                            row.addView(tv70);

                            TextView tv71 = new TextView(this);
                            tv71.setText("Balance ");
                            tv71.setTextColor(Color.BLACK);
                            tv71.setTextSize(13);
                            tv71.setGravity(Gravity.CENTER);
                            tv71.setPadding(10, 15, 10, 15);
                            tv71.setBackgroundResource(R.drawable.item);
                            row.addView(tv71);

                            TextView tv72 = new TextView(this);
                            tv72.setText("CreditLimit ");
                            tv72.setTextColor(Color.BLACK);
                            tv72.setTextSize(13);
                            tv72.setGravity(Gravity.CENTER);
                            tv72.setPadding(10, 15, 10, 15);
                            tv72.setBackgroundResource(R.drawable.item);
                            row.addView(tv72);


                            TextView tv73 = new TextView(this);
                            tv73.setText("SPL ");
                            tv73.setTextColor(Color.BLACK);
                            tv73.setTextSize(13);
                            tv73.setGravity(Gravity.CENTER);
                            tv73.setPadding(10, 15, 10, 15);
                            tv73.setBackgroundResource(R.drawable.item);
                            row.addView(tv73);


                            TextView tv74 = new TextView(this);
                            tv74.setText("SalesTax ");
                            tv74.setBackgroundColor(Color.parseColor("#f8f8f8"));
                            tv74.setTextColor(Color.BLACK);
                            tv74.setTextSize(13);
                            tv74.setGravity(Gravity.CENTER);
                            tv74.setPadding(10, 15, 10, 15);
                            tv74.setBackgroundResource(R.drawable.item);
                            row.addView(tv74);

                            TextView tv75 = new TextView(this);
                            tv75.setText("Address ");
                            tv75.setTextColor(Color.BLACK);
                            tv75.setTextSize(13);
                            tv75.setGravity(Gravity.CENTER);
                            tv75.setPadding(10, 15, 10, 15);
                            tv75.setBackgroundResource(R.drawable.item);
                            row.addView(tv75);

                            t1.addView(row);
                            t++;

                        }
                        if (t!=0) {

                            String a = cn.getSALECODE();
                            String f1 = cn.getBALANCE();
                            TableRow  row1= new TableRow(this);
                            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
                            row1.setLayoutParams(lp);

                            TextView t001= new TextView(this);
                            t001.setText(a.toString());
                            t001.setTextColor(Color.BLACK);
                            t001.setGravity(Gravity.CENTER);
                            t001.setBackgroundColor(Color.parseColor("#f8f8f8"));
                            t001.setBackgroundResource(R.drawable.item);
                            t001.setPadding(10, 15, 10, 15);
                            t001.setTextSize(13);
                            row1.addView(t001);

                            TextView tv1 = new TextView(this);
                            tv1.setText(cn.getMCODE());
                            tv1.setTextColor(Color.BLACK);
                            tv1.setGravity(Gravity.CENTER);
                            tv1.setBackgroundResource(R.drawable.item);
                            tv1.setPadding(10, 15, 10, 15);
                            tv1.setTextSize(13);
                            row1.addView(tv1);

                            TextView tv2 = new TextView(this);
                            tv2.setText(cn.getFNAME());
                            tv2.setTextColor(Color.BLACK);
                            tv2.setGravity(Gravity.CENTER);
                            tv2.setBackgroundColor(Color.parseColor("#f8f8f8"));
                            tv2.setBackgroundResource(R.drawable.item);
                            tv2.setPadding(10, 15, 10, 15);
                            tv2.setTextSize(13);
                            row1.addView(tv2);

                            TextView tv3 = new TextView(this);
                            tv3.setText(cn.getLNAME());
                            tv3.setTextColor(Color.BLACK);
                            tv3.setGravity(Gravity.CENTER);
                            tv3.setBackgroundResource(R.drawable.item);
                            tv3.setPadding(10, 15, 10, 15);
                            tv3.setTextSize(13);
                            row1.addView(tv3);

                            TextView tv4 = new TextView(this);
                            tv4.setText(cn.getURDUNAME());
                            tv4.setTextColor(Color.BLACK);
                            tv4.setGravity(Gravity.CENTER);
                            tv4.setBackgroundColor(Color.parseColor("#f8f8f8"));
                            tv4.setBackgroundResource(R.drawable.item);
                            tv4.setPadding(10, 15, 10, 15);
                            tv4.setTextSize(13);
                            row1.addView(tv4);

                            TextView tv5 = new TextView(this);
                            tv5.setText(cn.getCONTACT());
                            tv5.setTextColor(Color.BLACK);
                            tv5.setGravity(Gravity.CENTER);
                            tv5.setBackgroundResource(R.drawable.item);
                            tv5.setPadding(10, 15, 10, 15);
                            tv5.setTextSize(13);
                            row1.addView(tv5);

                            TextView tv7 = new TextView(this);
                            tv7.setText(cn.getCNIC());
                            tv7.setTextColor(Color.BLACK);
                            tv7.setGravity(Gravity.CENTER);
                            tv7.setBackgroundColor(Color.parseColor("#f8f8f8"));
                            tv7.setBackgroundResource(R.drawable.item);
                            tv7.setPadding(10, 15, 10, 15);
                            tv7.setTextSize(13);
                            row1.addView(tv7);


                            TextView tv8 = new TextView(this);
                            tv8.setText(cn.getSALETYPE());
                            tv8.setTextColor(Color.BLACK);
                            tv8.setGravity(Gravity.CENTER);
                            tv8.setBackgroundResource(R.drawable.item);
                            tv8.setPadding(10, 15, 10, 15);
                            tv8.setTextSize(13);
                            row1.addView(tv8);

                            TextView tv9 = new TextView(this);
                            tv9.setText(cn.getROUTE());
                            tv9.setTextColor(Color.BLACK);
                            tv9.setGravity(Gravity.CENTER);
                            tv9.setBackgroundResource(R.drawable.item);
                            tv9.setPadding(10, 15, 10, 15);
                            tv9.setTextSize(13);
                            row1.addView(tv9);

                            TextView tv10 = new TextView(this);
                            tv10.setText(cn.getAREA());
                            tv10.setTextColor(Color.BLACK);
                            tv10.setGravity(Gravity.CENTER);
                            tv10.setBackgroundResource(R.drawable.item);
                            tv10.setPadding(10, 15, 10, 15);
                            tv10.setTextSize(13);
                            row1.addView(tv10);

                            TextView tv11 = new TextView(this);
                            tv11.setText(cn.getZONE());
                            tv11.setTextColor(Color.BLACK);
                            tv11.setGravity(Gravity.CENTER);
                            tv11.setBackgroundResource(R.drawable.item);
                            tv11.setPadding(10, 15, 10, 15);
                            tv11.setTextSize(13);
                            row1.addView(tv11);

                            TextView tv12 = new TextView(this);
                            tv12.setText(cn.getBALANCE());
                            tv12.setTextColor(Color.BLACK);
                            tv12.setGravity(Gravity.CENTER);
                            tv12.setBackgroundResource(R.drawable.item);
                            tv12.setPadding(10, 15, 10, 15);
                            tv12.setTextSize(13);
                            row1.addView(tv12);

                            TextView tv13 = new TextView(this);
                            tv13.setText(cn.getCREDITLIMIT());
                            tv13.setTextColor(Color.BLACK);
                            tv13.setGravity(Gravity.CENTER);
                            tv13.setBackgroundResource(R.drawable.item);
                            tv13.setPadding(10, 15, 10, 15);
                            tv13.setTextSize(13);
                            row1.addView(tv13);

                            TextView tv14 = new TextView(this);
                            tv14.setText(cn.getSPL());
                            tv14.setTextColor(Color.BLACK);
                            tv14.setGravity(Gravity.CENTER);
                            tv14.setBackgroundResource(R.drawable.item);
                            tv14.setPadding(10, 15, 10, 15);
                            tv14.setTextSize(13);
                            row1.addView(tv14);

                            TextView tv16 = new TextView(this);
                            tv16.setText(cn.getSALETAX());
                            tv16.setTextColor(Color.BLACK);
                            tv16.setGravity(Gravity.CENTER);
                            tv16.setBackgroundColor(Color.parseColor("#f8f8f8"));
                            tv16.setBackgroundResource(R.drawable.item);
                            tv16.setPadding(5, 15, 5, 15);
                            tv16.setTextSize(13);
                            row1.addView(tv16);

                            TextView tv17 = new TextView(this);
                            tv17.setText(cn.getADDRESS());
                            tv17.setTextColor(Color.BLACK);
                            tv17.setGravity(Gravity.CENTER);
                            tv17.setBackgroundResource(R.drawable.item);
                            tv17.setPadding(5, 15, 5, 15);
                            tv17.setTextSize(13);
                            row1.addView(tv17);




                            final Button b1 = new Button(this);


                            t1.addView(row1);

                        }}t=0;

                }
                catch (Exception e){
                    //t2.setText(e.toString());
                }

            }
            else{
                // t2.setText("DataBase is not Readable");
            }

        }
    }
    public void DeleteClient(Integer i){

        datasource1 = new ProductInterface(this);
        String openresult=  datasource1.openforread();
        String openresul=  datasource1.open();
        if(openresult.equals("1")&&openresul.equals("1")){

            try{

                boolean x = datasource1.deleteoneclient(i);
                datasource1.close();
                //t11.setText(Boolean.toString(x));
                Toast.makeText(getApplicationContext(),Boolean.toString(x) ,Toast.LENGTH_SHORT).show();

            }
            catch (Exception e){
                // t11.setText(e.toString());
                Toast.makeText(getApplicationContext(),e.toString() ,Toast.LENGTH_SHORT).show();
                datasource1.close();
            }
        }
        else {
            // t11.setText("noo");
            Toast.makeText(getApplicationContext(),"no" ,Toast.LENGTH_SHORT).show();
        }


    }

}
