package com.example.tablewithlist;

import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ProductInterface {

    SQLiteDatabase database;
    DatabaseHelper dbHelper;
    private String[] allColumns = {DatabaseHelper.salecode ,DatabaseHelper.mcode,DatabaseHelper.fname,DatabaseHelper.lname,
       DatabaseHelper.urduname,DatabaseHelper.address,DatabaseHelper.contact,DatabaseHelper.cnic,
            DatabaseHelper.saletype,DatabaseHelper.route,DatabaseHelper.area,DatabaseHelper.zone,
            DatabaseHelper.balance,DatabaseHelper.creditlimit,DatabaseHelper.spl,DatabaseHelper.saletax


    };


    public ProductInterface(TableProductsActivity tableLayout) {
        dbHelper = new DatabaseHelper(tableLayout);

    }

    public String open()  {
        String x = "";
        try {
            database = dbHelper.getWritableDatabase();
            x = "1";
        }
        catch (Exception e){

            x = e.toString();
        }
        return x;
    }

    public  String openforread(){
        String x = "";
        try {
            database = dbHelper.getReadableDatabase();
            x = "1";
        }
        catch (Exception e){

            x = "0";
        }
        return x;


    }


    public void close() {
        dbHelper.close();
    }

    public boolean deleteoneclient(long c)throws Exception{


        //database.delete(ProductDatabase.table_name, ProductDatabase.product + " = " + c, null);
        return database.delete(DatabaseHelper.table_poducts_records, DatabaseHelper.salecode + "=" + c ,null) > 0;

    }

    public long getrowCount() {
        try {
            String countQuery = "SELECT  * FROM " + DatabaseHelper.table_poducts_records;

            SQLiteDatabase db = dbHelper.getReadableDatabase();
            long cnt = DatabaseUtils.queryNumEntries(db, DatabaseHelper.table_poducts_records);
            db.close();
            return cnt;
        }
        catch (Exception e){
            return 1000;
        }

    }

    public List<GetSetProducts> getAllClients(String dec, String Rou, String Typ) throws Exception{
        List<GetSetProducts> comments = new ArrayList<>();
        Cursor cursor;
        if(dec.equals("1")){
            cursor  = database.query(DatabaseHelper.table_poducts_records, allColumns , null, null, null, null, null);
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                GetSetProducts comment = cursorToGetSetValues(cursor);
                comments.add(comment);
                cursor.moveToNext();
            }
            // make sure to close the cursor
            this.close();
            cursor.close();
        }



        else if(dec.equals("2")){
            cursor  = database.rawQuery("SELECT  SALECODE , MCODE , FNAME , LNAME , URDUNAME , ADDRESS , CONTACT , CNIC , SALETYPE , ROUTE , AREA , ZONE , BALANCE ,CREDITLIMIT , SPL , SALETAX   FROM  PRODUCTSRECORDS WHERE SALETYPE ='" + Typ + "' AND ROUTE ='" + Rou +"'",null);

            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                GetSetProducts comment = cursorToGetSetValues(cursor);
                comments.add(comment);
                cursor.moveToNext();
            }
            // make sure to close the cursor
            this.close();
            cursor.close();


        }

        else if(dec.equals("3")){
            cursor  = database.rawQuery("SELECT  SALECODE , MCODE , FNAME , LNAME , URDUNAME , ADDRESS , CONTACT , CNIC , SALETYPE , ROUTE , AREA , ZONE , BALANCE ,CREDITLIMIT , SPL , SALETAX   FROM  PRODUCTSRECORDS WHERE SALETYPE ='" + Typ + "' AND ROUTE ='" + Rou +"'",null);

            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                GetSetProducts comment = cursorToGetSetValues(cursor);
                comments.add(comment);
                cursor.moveToNext();
            }
            // make sure to close the cursor
            this.close();
            cursor.close();


        }


        return comments;
    }

    private GetSetProducts cursorToGetSetValues(Cursor cursor) throws Exception {

        GetSetProducts comm = new GetSetProducts();

        comm.setSALECODE(cursor.getString(0));
        comm.setMCODE(cursor.getString(1));
        comm.setFNAME(cursor.getString(2));
        comm.setLNAME(cursor.getString(3));
        comm.setURDUNAME(cursor.getString(4));
        comm.setADDRESS(cursor.getString(5));
        comm.setCONTACT(cursor.getString(6));
        comm.setCNIC(cursor.getString(7));
        comm.setSALETYPE(cursor.getString(8));
        comm.setROUTE(cursor.getString(9));
        comm.setAREA(cursor.getString(10));
        comm.setZONE(cursor.getString(11));
        comm.setBALANCE(cursor.getString(12));
        comm.setCREDITLIMIT(cursor.getString(13));
        comm.setSPL(cursor.getString(14));
        comm.setSALETAX(cursor.getString(15));
        return comm;

    }


}
