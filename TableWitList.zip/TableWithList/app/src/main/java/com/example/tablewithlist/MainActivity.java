package com.example.tablewithlist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button BTN1,BTN2,BTN3,BTN4,BTN5;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BTN1=findViewById(R.id.btn1);
        BTN2=findViewById(R.id.btn2);
        BTN3=findViewById(R.id.btn3);
        BTN4=findViewById(R.id.btn4);
        BTN5=findViewById(R.id.btn5);
        databaseHelper=new DatabaseHelper(this);

        BTN1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.addProductRec();
                Toast.makeText(MainActivity.this, "CARD1", Toast.LENGTH_SHORT).show();

            }
        });
        BTN2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.addOrders();
                Toast.makeText(MainActivity.this, "Card2", Toast.LENGTH_SHORT).show();
            }
        });
        BTN3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Card3", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, TableProductsActivity.class));
            }
        });
        BTN4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Card4", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, TableOrdersActivity.class));
            }
        });

        BTN5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Card5", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, MainFragment.class));
            }
        });
    }
}
