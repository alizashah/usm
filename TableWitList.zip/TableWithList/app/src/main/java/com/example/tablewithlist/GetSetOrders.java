package com.example.tablewithlist;

public class GetSetOrders {

    public String ORDERCODE;
    public String BARCODE;
    public String NAME;
    public String SIZE;
    public String UNAME;
    public String RETAIL;
    public String WHOLESALE;
    public String TRADE;
    public String PERCENTAGE;
    public String TAX;
    public String SUBCATAGARY;
    public String CATEGARY;
    public String COMPANY;
    public String TYPE;
    public String PACKSIZE;
    public String WEIGHT;
    public String WEIGHTUNIT;
    public String CURRENTSTOCK;

    public String getORDERCODE() {
        return ORDERCODE;
    }

    public void setORDERCODE(String ORDERCODE) {
        this.ORDERCODE = ORDERCODE;
    }

    public String getBARCODE() {
        return BARCODE;
    }

    public void setBARCODE(String BARCODE) {
        this.BARCODE = BARCODE;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public String getSIZE() {
        return SIZE;
    }

    public void setSIZE(String SIZE) {
        this.SIZE = SIZE;
    }

    public String getUNAME() {
        return UNAME;
    }

    public void setUNAME(String UNAME) {
        this.UNAME = UNAME;
    }

    public String getRETAIL() {
        return RETAIL;
    }

    public void setRETAIL(String RETAIL) {
        this.RETAIL = RETAIL;
    }

    public String getWHOLESALE() {
        return WHOLESALE;
    }

    public void setWHOLESALE(String WHOLESALE) {
        this.WHOLESALE = WHOLESALE;
    }

    public String getTRADE() {
        return TRADE;
    }

    public void setTRADE(String TRADE) {
        this.TRADE = TRADE;
    }

    public String getPERCENTAGE() {
        return PERCENTAGE;
    }

    public void setPERCENTAGE(String PERCENTAGE) {
        this.PERCENTAGE = PERCENTAGE;
    }

    public String getTAX() {
        return TAX;
    }

    public void setTAX(String TAX) {
        this.TAX = TAX;
    }

    public String getSUBCATAGARY() {
        return SUBCATAGARY;
    }

    public void setSUBCATAGARY(String SUBCATAGARY) {
        this.SUBCATAGARY = SUBCATAGARY;
    }

    public String getCATEGARY() {
        return CATEGARY;
    }

    public void setCATEGARY(String CATEGARY) {
        this.CATEGARY = CATEGARY;
    }

    public String getCOMPANY() {
        return COMPANY;
    }

    public void setCOMPANY(String COMPANY) {
        this.COMPANY = COMPANY;
    }

    public String getTYPE() {
        return TYPE;
    }

    public void setTYPE(String TYPE) {
        this.TYPE = TYPE;
    }

    public String getPACKSIZE() {
        return PACKSIZE;
    }

    public void setPACKSIZE(String PACKSIZE) {
        this.PACKSIZE = PACKSIZE;
    }

    public String getWEIGHT() {
        return WEIGHT;
    }

    public void setWEIGHT(String WEIGHT) {
        this.WEIGHT = WEIGHT;
    }

    public String getWEIGHTUNIT() {
        return WEIGHTUNIT;
    }

    public void setWEIGHTUNIT(String WEIGHTUNIT) {
        this.WEIGHTUNIT = WEIGHTUNIT;
    }

    public String getCURRENTSTOCK() {
        return CURRENTSTOCK;
    }

    public void setCURRENTSTOCK(String CURRENTSTOCK) {
        this.CURRENTSTOCK = CURRENTSTOCK;
    }
}
